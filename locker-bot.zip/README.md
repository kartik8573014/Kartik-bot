# Kartik Rajput Locker Bot 🚀

Messenger Locker Bot (Node.js + Express + ws3-fca)

## Deploy on Render
1. Upload this repo as a **ZIP** or push to GitHub.
2. Create new **Web Service** on Render.
3. Add `web: node server.js` in Procfile.
4. Set **Build Command**: `npm install`
5. Set **Start Command**: `npm start`

Then open your Render URL and upload `appstate.json` to start bot 🎉
